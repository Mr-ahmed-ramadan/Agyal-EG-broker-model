Agyal brand kit

Primary mark: the arch (agyal-arch-*). Seal and ladder are alternates.

Colourways
  color  - forest #2F5A45 with the bronze #A8823A doorway, for light grounds
  ivory  - ivory #F7F4EC with the bronze doorway, for dark or forest grounds
  mono   - one colour, for single-ink printing and engraving

Wordmarks are outlined from Cormorant Garamond (Agyal) and Amiri (Arabic),
both under the SIL Open Font License, so the files need no fonts installed.

Clear space on all sides is the height of the bronze doorway.
Do not recolour, tilt, outline, stretch or add effects to the mark.

https://invest.egypt.agyal.net/brand
